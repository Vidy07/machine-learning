package slip6;
public interface Command{
    public void execute();
    public void undo();
}