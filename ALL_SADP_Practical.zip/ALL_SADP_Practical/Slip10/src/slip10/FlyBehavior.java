package slip10;

public interface FlyBehavior {
	public void fly();
}
