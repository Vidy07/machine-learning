package slip10;

public interface QuackBehavior {
	public void quack();
}
