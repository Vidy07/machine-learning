package slip19;

public class NYStyleVeggiePizza extends Pizza{
    NYStyleVeggiePizza()
    {
        name="Ny style sauce Veggie pizza";
        dough="Thin crust dough";
        sauce="Mariana Sauce";
        toppings.add("Olives");
        toppings.add("Mushrooms");
    }
}
