package slip19;

import java.util.*;
public class ChicagoStyleVeggiePizza extends Pizza{
    ChicagoStyleVeggiePizza()
    {
        name="Chicago style deep dish Veggie pizza";
        dough="Extra Thick crust dough";
        sauce="Plum Tomato Sauce";
        toppings.add("Shredded Mozzarella Cheese");
    }
}