package slip19;

public class NYStyleCheesePizza extends Pizza{
    NYStyleCheesePizza()
    {
        name="Ny style sauce cheese pizza";
        dough="Thin crust dough";
        sauce="Mariana Sauce";
        toppings.add("Grated Regianno Cheese");
    }
}