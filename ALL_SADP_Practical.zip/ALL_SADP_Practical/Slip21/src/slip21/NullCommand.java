package slip21;
public class NullCommand implements Command{
    public void execute(){};
    public void undo(){};
}