package slip26;

public interface FlyBehavior {
	public void fly();
}
