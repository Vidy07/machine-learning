package slip26;

public interface QuackBehavior {
	public void quack();
}
