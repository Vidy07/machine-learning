package slip24;
public class DinerMergerTestDrive{
    public static void main(String[] ar)
    {
        Waitress waitress=new Waitress();
        waitress.printMenu();

    }
}