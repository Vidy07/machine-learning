package slip24;
import java.util.Iterator;
public interface Menu{
    public Iterator<MenuItem> createIterator();
}