package slip30;
import java.util.*;
public class ChicagoStyleCheesePizza extends Pizza{
     
    ChicagoStyleCheesePizza()
    {
        name="Chicago style deep dish Cheese pizza";
        dough="Extra Thick crust dough";
        sauce="Plum Tomato Sauce";
        toppings=new ArrayList<String>();
        toppings.add("Corns");
        toppings.add("Veggie");
    }
}