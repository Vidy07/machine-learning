module.exports = function getDate(){
    return new Date().toLocaleString()
}