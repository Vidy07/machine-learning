let output = "Hello World!"

console.log(output.toUpperCase())